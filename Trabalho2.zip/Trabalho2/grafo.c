#include "grafo.h"
#include <stdlib.h>

#include "pilha.h"
#include "fila.h"
#include "labirinto.h"

void adicionarAresta(Aresta** listaAdjacencia, No* destino) {
    Aresta* novaAresta = (Aresta*)malloc(sizeof(Aresta));
    novaAresta->destino = destino;
    novaAresta->proximaAresta = *listaAdjacencia;
    *listaAdjacencia = novaAresta;
}

// Função para criar o grafo a partir do labirinto
void criarGrafo(char labirinto[LINHAS][COLUNAS], No* nos[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            if (labirinto[i][j] != PAREDE) {
                No* atual = (No*)malloc(sizeof(No));
                atual->linha = i;
                atual->coluna = j;
                atual->visitado = 0;
                atual->percorrido = 0;
                //atual->proximo = NULL;
                atual->listaAdjacencia = NULL;
                nos[i][j] = atual;

                // Verificar células adjacentes
                if (i > 0 && labirinto[i - 1][j] != PAREDE) {
                    if (nos[i - 1][j] != NULL) {
                        adicionarAresta(&(atual->listaAdjacencia), nos[i - 1][j]);
                        adicionarAresta(&(nos[i - 1][j]->listaAdjacencia), atual);
                    }
                }
                if (i < LINHAS - 1 && labirinto[i + 1][j] != PAREDE) {
                    if (nos[i + 1][j] != NULL) {
                        adicionarAresta(&(atual->listaAdjacencia), nos[i + 1][j]);
                        adicionarAresta(&(nos[i + 1][j]->listaAdjacencia), atual);
                    }
                }
                if (j > 0 && labirinto[i][j - 1] != PAREDE) {
                    if (nos[i][j - 1] != NULL) {
                        adicionarAresta(&(atual->listaAdjacencia), nos[i][j - 1]);
                        adicionarAresta(&(nos[i][j - 1]->listaAdjacencia), atual);
                    }
                }
                if (j < COLUNAS - 1 && labirinto[i][j + 1] != PAREDE) {
                    if (nos[i][j + 1] != NULL) {
                        adicionarAresta(&(atual->listaAdjacencia), nos[i][j + 1]);
                        adicionarAresta(&(nos[i][j + 1]->listaAdjacencia), atual);
                    }
                }
            } else {
                nos[i][j] = NULL; // Marcar células de parede como nulas
            }
        }
    }
}
