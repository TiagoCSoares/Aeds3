#ifndef BARABASI_H
#define BARABASI_H

#include <stdlib.h>
#include <stdio.h>


#include "grafo.h"
#include "closeness.h"
#include "../ManipularArquivos/alterarArquivos.h"

void barabasiAlbert(int numVertices, int numInicial);

#endif